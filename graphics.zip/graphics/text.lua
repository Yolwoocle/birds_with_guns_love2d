------------------------------------------
-- text
--
-- default font by 04
-- http://www.04.jp.org
------------------------------------------
function initText()
    log.log("initializing text")
    __alphabet = " !\"#$%&'()*+,-./" .. "0123456789:;<=>?" .. "@ABCDEFGHIJKLMNO" .. "PQRSTUVWXYZ[\\]^_" ..
                   "`abcdefghijklmno" .. "pqrstuvwxyz{|}~¢"
    __currentFont = nil
end

function setFont(_font)
    __currentFont = _font
end

function makeFont(_assetStr)
    local imageData = love.image.newImageData(_assetStr)
    local f = {
        imageData = imageData,
        image = love.graphics.newImage(imageData),
        glyphs = {},
        kerning = {},
        height = 6,
    }
    -- make glyphs
    for y = 0, 5 do
        local px = 0
        for x = 0, 15 do
            local pos = x + y * 16 + 1
            local char = string.sub(__alphabet, pos, pos)

            local py = y * 8

            -- find width
            local w = 0
            local done = false
            while not done do
                local r, g, b, a = f.imageData:getPixel(px + w, py)
                if a == 0 or r == 1 then
                    w = w + 1
                else
                    done = true
                end
            end

            -- find height
            local h = 0
            done = false
            while not done do
                local r, g, b, a = f.imageData:getPixel(px, py + h)
                if a == 0 or r == 1 then
                    h = h + 1
                else
                    done = true
                end
            end

            f.glyphs[char] = love.graphics.newQuad(px, py, w, h, f.image:getDimensions())
            f.kerning[char] = w + 1

            -- skip to next
            px = px + w + 1
            done = false
            while not done do
                local r, g, b = f.imageData:getPixel(px, py)
                if a ~= 0 then
                    done = true
                else
                    px = px + 1
                end
            end

        end
    end

    return f
end

function pront(_str, _x, _y, _c, _options)
    _options = _options or {}
    _str = tostring(_str)
    local width = textWidth(_str)
    local sx = flr(_x - (_options.center and width / 2 or (_options.right and width or 0)))

    if _options.underline then
        line(sx, _y+__currentFont.height, sx + width, _y+__currentFont.height, _options.underline)
    end

    if _options.dropShadow then
        pr(_str, sx, _y + 1, _options.dropShadow)
        if _options.underline then
            line(sx, _y+__currentFont.height+1, sx + width, _y+__currentFont.height+1, _options.dropShadow)
        end
    end

    pr(_str, sx, _y, _c)
end

function pr(_str, _x, _y, _c)
    _str = tostring(_str)
    local px = flr(_x)
    local x0 = px
    local y0 = flr(_y)
    local i = 1
    while i <= #_str do

        local char = string.sub(_str, i, i)

        local glyph = __currentFont.glyphs[char]
        if glyph ~= nil then
            local dy = y0
            local dx = x0

            love.graphics.setColor(__colors[__palette[_c]])

            love.graphics.draw(__currentFont.image, glyph, flr(dx), flr(dy))
            x0 = x0 + __currentFont.kerning[char]

        else
            if char == '\n' then
                y0 = y0 + 8
                x0 = px
            end
            -- todo: handle missing glyph somehow?
        end
        i = i + 1
    end

end

function textWidth(str)
    local w = 0
    local x0 = x
    for i = 1, #str do
        local char = string.sub(str, i, i)
        local glyph = __currentFont.glyphs[char]
        if glyph ~= nil then
            w = w + __currentFont.kerning[char]
        end
    end
    return w - 1
end

function textHeight(str)
    return 6
end

