------------------------------------------
-- tilemap
------------------------------------------
function makeTilemap(_mapWidth, _mapHeight, _spritesheet)
    local tm = {
        mapWidth = _mapWidth,
        mapHeight = _mapHeight,
        spritesheet = _spritesheet,
        tileSize = _spritesheet.spriteWidth,
        map = {},

        mset = function(tm, tx, ty, id)
            -- guard against setting outside the map
            if tx<0 or tx>=tm.mapWidth or ty<0 or ty>=tm.mapHeight then
                return 
            end
            tm.map[tx][ty] = id
        end,

        mget = function(tm, tx, ty)
            -- always return 0 if outside map
            if tx < 0 or tx > tm.mapWidth - 1 or ty < 0 or ty > tm.mapHeight - 1 then
                return 0
            end
            return tm.map[tx][ty]
        end,

        mset_rectfill = function(tm, x1, y1, x2, y2, id)    
            for x = x1, x2 do
                for y = y1, y2 do
                    tm:mset(x, y, id)
                end
            end
        end,

        mset_circfill = function(tm, cx, cy, r, id)
            for y = -r, r do
                for x = -r, r do
                    if x * x + y * y < r * r then
                        tm:mset(flr(cx + x), flr(cy + y), id)
                    end
                end
            end
        end,
  
        draw = function(tm, sx, sy, cx, cy, cw, ch)
            if not cw then
                cw = tm.mapWidth - cx
            end
            if not ch then
                ch = tm.mapHeight - cy
            end

            setSpritesheet( tm.spritesheet )
            for tx = cx, cx + cw - 1 do
                for ty = cy, cy + ch - 1 do
                    local id = tm.map[tx][ty]
                    if id > 0 then
                        local x = sx + (tx - cx) * tm.tileSize
                        local y = sy + (ty - cy) * tm.tileSize
                        spr(id, x, y)
                    end
                end
            end

        end

    }

    for x = 0, _mapWidth - 1 do
        tm.map[x] = {}
        for y = 0, _mapHeight - 1 do
            tm.map[x][y] = 0
        end
    end

    return tm
end
