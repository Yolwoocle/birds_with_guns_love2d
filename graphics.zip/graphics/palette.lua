function loadPalette(_assetStr)
    local imgData=love.image.newImageData(_assetStr)
    __colors = {}
    local numCols = 0
    for x = 0, imgData:getWidth()-1 do
        local r,g,b = imgData:getPixel(x,0)
        __colors[numCols] = {r,g,b,1}
        numCols = numCols + 1
    end
    __currentColorID = 7
   
    __palette = {}
    for i = 0, numCols-1 do
        __palette[i] = i
    end

end

function initPalette()
    -- pico8 palette
    log.log("setting up palette")
    __colors = {}
    __colors[0] = {0, 0, 0, 255}
    __colors[1] = {29, 43, 83, 255}
    __colors[2] = {126, 37, 83, 255}
    __colors[3] = {0, 135, 81, 255}

    __colors[4] = {171, 82, 54, 255}
    __colors[5] = {95, 87, 79, 255}
    __colors[6] = {194, 195, 199, 255}
    __colors[7] = {255, 241, 232, 255}

    __colors[8] = {255, 0, 77, 255}
    __colors[9] = {255, 163, 0, 255}
    __colors[10] = {255, 236, 39, 255}
    __colors[11] = {0, 228, 54, 255}

    __colors[12] = {41, 173, 255, 255}
    __colors[13] = {131, 118, 156, 255}
    __colors[14] = {255, 119, 168, 255}
    __colors[15] = {255, 204, 170, 255}

    for i = 0, 15 do
        for j = 1, 4 do
            __colors[i][j] = __colors[i][j] / 255
        end
    end

    __currentColorID = 7

    -- array for palette swapping
    __palette = {}
    for i = 0, 15 do
        __palette[i] = i
    end

    -- shading palettes
    dpal1 = {0, 0, 1, 5, 2, 1, 13, 6, 2, 4, 9, 3, 13, 5, 8, 9}
    dpal2 = {0, 0, 0, 1, 1, 0, 5, 13, 1, 2, 4, 5, 5, 1, 2, 4}
    lpal = {1, 5, 4, 11, 9, 13, 7, 7, 14, 10, 7, 7, 7, 6, 15, 7}

    -- error colors
    -- 3 5 1      3 1 1
    -- 6 13 5     6 5 5 
    -- 12 13 5   12 5 5

    -- shader stuff
    __paletteSwapShaderCode_textures = [[
        extern int dither = 0;
        extern int numColors;
        extern vec4 oldColors[16];
        extern vec4 newColors[16];
        vec4 effect( vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords ){
            color = Texel(texture, texture_coords );

            if (dither == 0 || fract(screen_coords.x * 0.5 + screen_coords.y * 0.5) < 0.5) {
                for (int i = 0; i < numColors; i++) {
                    if (color == oldColors[i]) {  
                        color = newColors[i];
                        break;
                    }
                }
            }

            return color;
        } 
    ]]

    __paletteSwapShaderCode_primitives = [[
        extern int dither = 0;
        extern int numColors;
        extern vec4 oldColors[16];
        extern vec4 newColors[16];
        vec4 effect( vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords ){
            vec4 pixel = Texel(texture, texture_coords );

            if (dither == 0 || fract(screen_coords.x * 0.5 + screen_coords.y * 0.5) < 0.5) {
                for (int i = 0; i < numColors; i++) {
                    if (color == oldColors[i]) {
                        color = newColors[i];
                        break;
                    }
               }
            }

            return color * pixel;
        } 
    ]]

    __shOldColors = {}
    __shNewColors = {}
    __shaders = {
        --tex = love.graphics.newShader(__paletteSwapShaderCode_textures),
        --prim = love.graphics.newShader(__paletteSwapShaderCode_primitives)
    }

    __currentShader = __shaders["tex"]
    __shaderIsActive = false
end

function color(n)
    __currentColorID = n
end

function __setShaderType(key)
    __currentShader = __shaders[key]
end

function pal(a, b)
    if a == nil then
        -- restore palette
        for i = 0, 15 do
            __palette[i] = i
        end

        -- clear swap list
        __shOldColors = {}
        __shNewColors = {}

        -- clear shader
        love.graphics.setShader()
        __shaderIsActive = false

        return
    end

    if type(a) == "table" then
        -- replace entire target palette
        for i = 1, 16 do
            __palette[i - 1] = a[i]
        end
        -- set shader
        love.graphics.setShader(__currentShader)

        -- update color arrays
        __shOldColors = {}
        __shNewColors = {}
        for i = 0, 15 do
            if __palette[i] ~= i then
                add(__shOldColors, __colors[i])
                add(__shNewColors, __colors[__palette[i]])
            end
        end
        __currentShader:send("numColors", #__shOldColors)
        __currentShader:send("oldColors", unpack(__shOldColors))
        __currentShader:send("newColors", unpack(__shNewColors))
        __currentShader:send("dither", b and 1 or 0)
    else
        -- replace single color
        __palette[a] = b

        -- update color arrays
        add(__shOldColors, __colors[a])
        add(__shNewColors, __colors[__palette[b]])

        love.graphics.setShader(__currentShader)

        -- update shader
        __currentShader:send("numColors", #__shOldColors)
        __currentShader:send("oldColors", unpack(__shOldColors))
        __currentShader:send("newColors", unpack(__shNewColors))
        __currentShader:send("dither", 0)

    end
end

