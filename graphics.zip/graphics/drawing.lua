require("src.skrovet.graphics.palette")


function initGraphics()
    log.log("initializing graphics")

    love.graphics.setLineWidth(1)
    love.graphics.setLineStyle("rough")
    love.graphics.setDefaultFilter("nearest", "nearest")

    initPalette()
    
    -- camera
    log.log("setting up camera")
    __camera = {x = 0, y = 0}

    skrovet.graphics = {
        activeSpritesheetStack = {},
        clipStack = { },
        camStack = { },
    }
end

------------------------------------------
-- camera
------------------------------------------
function camera(_px, _py, push)
    if not push then
        skrovet.graphics.camStack = {}
    end

    -- back to origin
    love.graphics.translate( __camera.x, __camera.y )

    -- store new pos
    __camera.x = flr(_px or 0)
    __camera.y = flr(_py or 0)

    -- go to new pos
    love.graphics.translate( -__camera.x, -__camera.y )
    add( skrovet.graphics.camStack, {__camera.x, __camera.y} )
end

function popCamStack()
    local data = deli( skrovet.graphics.camStack, #skrovet.graphics.camStack )
    local data = skrovet.graphics.camStack[#skrovet.graphics.camStack]
    camera( data[1], data[2] )
end


function clip( x, y, width, height, push )
    if not push then
        skrovet.graphics.clipStack = {}
    end
    love.graphics.setScissor( x, y, width, height )
    add( skrovet.graphics.clipStack, {x,y,width,height} )
end

function popClipStack()
    local data = deli( skrovet.graphics.clipStack, #skrovet.graphics.clipStack )
    local data = skrovet.graphics.clipStack[#skrovet.graphics.clipStack]
    clip( data[1], data[2], data[3], data[4])
end

------------------------------------------
-- drawing primitives
------------------------------------------
function cls(_c) love.graphics.clear(__colors[__palette[_c]]) end

function pset(_px, _py, _c)
    if _c then
        __currentColorID = _c
    else
        _c = __currentColorID
    end

    love.graphics.setColor(__colors[__palette[_c]])
    love.graphics.points(flr(_px) + 0.5,
                         flr(_py) + 0.5)
end

function line(_px1, _py1, _px2, _py2, _c)
    if _c then
        __currentColorID = _c
    else
        _c = __currentColorID
    end

    love.graphics.setColor(__colors[__palette[_c]])
    love.graphics.line( flr(_px1) +0.5, flr(_py1) +0.5, 
                        flr(_px2) +0.5, flr(_py2) +0.5)
end

function rect(_px1, _py1, _px2, _py2, _c)
    if _c then
        __currentColorID = _c
    else
        _c = __currentColorID
    end

    local x = flr(min(_px1, _px2)) + 0.5
    local y = flr(min(_py1, _py2)) + 0.5
    local w = abs(_px1 - _px2) 
    local h = abs(_py1 - _py2)

    love.graphics.setColor(__colors[__palette[_c]])
    love.graphics.rectangle("line", x, y, w, h)
end

function rectfill(_px1, _py1, _px2, _py2, _c)
    if _c then
        __currentColorID = _c
    else
        _c = __currentColorID
    end

    local x = flr(min(_px1, _px2))
    local y = flr(min(_py1, _py2))
    local w = abs(_px1 - _px2) +1
    local h = abs(_py1 - _py2) +1

    love.graphics.setColor(__colors[__palette[_c]])
    love.graphics.rectangle("fill", x, y, w, h)
end

function circ(_px, _py, _r, _c)
    if _c then
        __currentColorID = _c
    else
        _c = __currentColorID
    end

    love.graphics.setColor(__colors[__palette[_c]])
    love.graphics.circle("line", _px, _py, _r)
end

function circfill(_px, _py, _r, _c)
    if _c then
        __currentColorID = _c
    else
        _c = __currentColorID
    end

    love.graphics.setColor(__colors[__palette[_c]])
    love.graphics.circle("fill", _px, _py, _r)
end
