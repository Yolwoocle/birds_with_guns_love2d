
------------------------------------------
-- sprites
------------------------------------------
function drawImg(_img, _px, _py)
    love.graphics.draw(_img, _px, _py)
end


function makeSpritesheet(_assetName, _sheetData, _h)
    local img = love.graphics.newImage(_assetName)
    if img == nil then
        log.log("asset not found (makeSpritesheet)", log.WARNING)
    end
    
    local spritesheet = {
        asset = _assetName,
        image = img,
        sheetData = {},

        draw = function(_ss, _id, _px, _py, _rot, _sx, _sy, _ox, _oy, _tw, _th)
            setSpritesheet( _ss )
            spr(_id, _px, _py, _rot, _sx, _sy, _ox, _oy, _tw, _th )
        end
    }

    if type(_sheetData) ~= "table" then
        -- assume w and h are entered
        local _w = _sheetData
        local id = 0
        for y = 0, img:getHeight()-1, _h do
            for x = 0, img:getWidth()-1, _w do
                spritesheet.sheetData[id] = {
                    x=x, y=y, 
                    w=_w, h=_h
                }
                id = id + 1
            end
        end
        spritesheet.spriteWidth = _w
        spritesheet.spriteHeight = _h
        log.log("extracted "..id.." sprites from ".._assetName)
    else
        -- read data from table
        local id = 0
        local count = 0
        for _,data in ipairs(_sheetData.sprites) do
            spritesheet.sheetData[data.id] = {
                x=data.x, y=data.y, 
                w=data.w, h=data.h
            }
            count = count + 1
        end
        log.log("extracted "..count.." sprites from ".._assetName)
    end
    return spritesheet
end

function setSpritesheet(sheet)
    skrovet.graphics.activeSpritesheet = sheet
end

--[[
function pushSpritesheet(sheet)
    skrovet.graphics.activeSpritesheet = sheet
    add( skrovet.graphics.activeSpritesheetStack, sheet )
end

function popSpritesheet()
    del(skrovet.graphics.activeSpritesheetStack, skrovet.graphics.activeSpritesheetStack[#skrovet.graphics.activeSpritesheetStack])
    skrovet.graphics.activeSpritesheet = skrovet.graphics.activeSpritesheetStack[#skrovet.graphics.activeSpritesheetStack]
end
]]--

function sspr(_sx, _sy, _sw, _sh, _dx, _dy, _dw, _dh)
    _dw = _dw or _sw
    _dh = _dh or _sh

    if not __spriteQuad then
        __spriteQuad = love.graphics.newQuad(_sx, _sy, _sw, _sh,
                                             skrovet.graphics.activeSpritesheet.image:getDimensions())
    else
        __spriteQuad:setViewport(_sx, _sy, _sw, _sh,
                                 skrovet.graphics.activeSpritesheet.image:getDimensions())
    end
    love.graphics.setColor({1,1,1})
    love.graphics.draw(skrovet.graphics.activeSpritesheet.image, __spriteQuad, flr(_dx),
                       flr(_dy), 0, _dw / _sw, _dh / _sh)

end


function spr(_id, _px, _py, _rot, _sx, _sy, _ox, _oy, _tw, _th, _col )
    _rot = _rot or 0
    _sx = _sx or 1
    _sy = _sy or 1
    _ox = _ox or 0
    _oy = _oy or 0
    _tw = _tw or 1
    _th = _th or 1

    local ssx = skrovet.graphics.activeSpritesheet.sheetData[_id].x
    local ssy = skrovet.graphics.activeSpritesheet.sheetData[_id].y
    local ssw = skrovet.graphics.activeSpritesheet.sheetData[_id].w * _tw
    local ssh = skrovet.graphics.activeSpritesheet.sheetData[_id].h * _th

    if not __spriteQuad then
        __spriteQuad = love.graphics.newQuad(ssx, ssy, ssw, ssh,
                                             skrovet.graphics.activeSpritesheet.image:getDimensions())
    else
        __spriteQuad:setViewport(ssx, ssy, ssw, ssh,
                                 skrovet.graphics.activeSpritesheet.image:getDimensions())
    end

    love.graphics.setColor(_col or {1,1,1})
    love.graphics.draw(skrovet.graphics.activeSpritesheet.image, __spriteQuad, flr(_px),
                       flr(_py), _rot, _sx, _sy, _ox, _oy)
end   

function spr_old(_id, _px, _py, _tw, _th, _hflip, _vflip)
    _tw, _th = _tw or 1, _th or 1

    local cx = _id % skrovet.graphics.activeSpritesheet.spritesPerRow
    local cy = flr(_id / skrovet.graphics.activeSpritesheet.spritesPerRow)

    local scx, scy = 1, 1
    if _hflip then
        scx = -1
        _px = _px + _tw * skrovet.graphics.activeSpritesheet.spriteWidth
    end
    if _vflip then
        scy = -1
        _py = _py + _th * skrovet.graphics.activeSpritesheet.spriteHeight
    end

    if not __spriteQuad then
        __spriteQuad = love.graphics.newQuad(cx * skrovet.graphics.activeSpritesheet.spriteWidth,
                                             cy * skrovet.graphics.activeSpritesheet.spriteHeight,
                                             _tw * skrovet.graphics.activeSpritesheet.spriteWidth,
                                             _th * skrovet.graphics.activeSpritesheet.spriteHeight,
                                             skrovet.graphics.activeSpritesheet.image:getDimensions())
    else
        __spriteQuad:setViewport(cx * skrovet.graphics.activeSpritesheet.spriteWidth, cy * skrovet.graphics.activeSpritesheet.spriteHeight,
                                 _tw * skrovet.graphics.activeSpritesheet.spriteWidth, _th * skrovet.graphics.activeSpritesheet.spriteHeight,
                                 skrovet.graphics.activeSpritesheet.image:getDimensions())
    end
    love.graphics.setColor({1,1,1})
    love.graphics.draw(skrovet.graphics.activeSpritesheet.image, __spriteQuad, flr(_px),
                       flr(_py), 0, scx, scy)
end
